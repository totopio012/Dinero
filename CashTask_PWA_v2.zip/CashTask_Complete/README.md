# CashTask — proyecto completo inicial

App de recompensas con:
- interfaz móvil tipo PWA
- tareas y puntos
- billetera
- solicitudes de retiro
- referidos
- panel admin básico
- API Node/Express
- almacenamiento local JSON para desarrollo

## Ejecutar
1. Instala Node.js 20+.
2. En esta carpeta ejecuta:
   npm install
   npm start
3. Abre http://localhost:3000

## Importante
Es un proyecto inicial funcional, no un sistema de pagos real todavía.
Para producción hay que conectar:
- proveedor de anuncios recompensados
- proveedor de encuestas/ofertas
- autenticación segura
- base de datos administrada
- proveedor de pagos (PayPal/otro)
- antifraude, KYC/edad cuando corresponda, términos y privacidad
- publicación en App Store/Google Play

Nunca se deben inventar pagos o ganancias. Las recompensas reales dependen de los proveedores.

## PWA / instalación en el teléfono
La versión actual incluye manifest, iconos y service worker. Con el servidor publicado por HTTPS, se puede instalar desde el navegador como una app.

En iPhone: abrir la web en Safari → Compartir → Añadir a pantalla de inicio.

Nota: el modo PWA no convierte por sí solo los anuncios, encuestas o retiros en servicios reales; esos proveedores deben conectarse y cumplir sus requisitos.
