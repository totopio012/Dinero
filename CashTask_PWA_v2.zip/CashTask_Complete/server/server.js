const express=require('express');
const cors=require('cors');
const fs=require('fs');
const path=require('path');
const app=express();
const PORT=process.env.PORT||3000;
app.use(cors()); app.use(express.json()); app.use(express.static(path.join(__dirname,'../public')));
const dbFile=path.join(__dirname,'db.json');
let db=fs.existsSync(dbFile)?JSON.parse(fs.readFileSync(dbFile)):({
 users:[{id:1,name:'Demo',email:'demo@cashtask.local',points:0,createdAt:new Date().toISOString()}],
 tasks:[
  {id:1,title:'Ver anuncio',type:'ad',reward:50,active:true},
  {id:2,title:'Encuesta rápida',type:'survey',reward:250,active:true},
  {id:3,title:'Oferta de juego',type:'offer',reward:500,active:true},
  {id:4,title:'Bono diario',type:'daily',reward:100,active:true}
 ],
 withdrawals:[], activity:[]
});
function save(){fs.writeFileSync(dbFile,JSON.stringify(db,null,2))}
app.get('/api/tasks',(req,res)=>res.json(db.tasks.filter(t=>t.active)));
app.get('/api/user/:id',(req,res)=>{
 const u=db.users.find(x=>x.id==req.params.id); if(!u)return res.status(404).json({error:'Usuario no encontrado'});
 res.json(u);
});
app.post('/api/claim',(req,res)=>{
 const {userId,taskId}=req.body; const u=db.users.find(x=>x.id==userId); const t=db.tasks.find(x=>x.id==taskId&&x.active);
 if(!u||!t)return res.status(400).json({error:'Datos inválidos'});
 u.points+=t.reward; db.activity.push({userId,taskId,kind:'reward',points:t.reward,createdAt:new Date().toISOString()}); save();
 res.json({ok:true,points:u.points});
});
app.post('/api/withdraw',(req,res)=>{
 const {userId,amount,paypal}=req.body; const u=db.users.find(x=>x.id==userId);
 if(!u||!paypal||!Number.isFinite(Number(amount))||Number(amount)<5)return res.status(400).json({error:'Solicitud inválida'});
 const cost=Math.round(Number(amount)*1000);
 if(u.points<cost)return res.status(400).json({error:'Saldo insuficiente'});
 u.points-=cost;
 const w={id:Date.now(),userId,amount:Number(amount),paypal,status:'pending',createdAt:new Date().toISOString()};
 db.withdrawals.push(w); db.activity.push({userId,kind:'withdrawal',points:-cost,createdAt:w.createdAt}); save();
 res.json({ok:true,withdrawal:w,points:u.points});
});
app.get('/api/admin/summary',(req,res)=>res.json({
 users:db.users.length, tasks:db.tasks.length, pendingWithdrawals:db.withdrawals.filter(w=>w.status==='pending').length,
 pointsIssued:db.activity.filter(a=>a.points>0).reduce((s,a)=>s+a.points,0)
}));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'../public/index.html')));
app.listen(PORT,()=>console.log(`CashTask running on ${PORT}`));
